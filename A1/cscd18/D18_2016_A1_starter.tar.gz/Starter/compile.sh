g++ -O4 -g -fopenmp Boids.cpp -l3ds -lGL -lglut -lGLU -lglui -lm -o Boids
